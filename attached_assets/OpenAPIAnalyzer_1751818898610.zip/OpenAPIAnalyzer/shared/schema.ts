import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email"),
  walletAddress: text("wallet_address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const tokenInfo = pgTable("token_info", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  name: text("name").notNull(),
  currentPrice: decimal("current_price", { precision: 18, scale: 8 }).notNull(),
  marketCap: decimal("market_cap", { precision: 18, scale: 2 }),
  volume24h: decimal("volume_24h", { precision: 18, scale: 2 }),
  priceChange24h: decimal("price_change_24h", { precision: 8, scale: 4 }),
  holders: integer("holders"),
  totalSupply: decimal("total_supply", { precision: 18, scale: 0 }).notNull(),
  contractAddresses: jsonb("contract_addresses").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const communityStats = pgTable("community_stats", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(),
  memberCount: integer("member_count").notNull(),
  url: text("url"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertTokenInfoSchema = createInsertSchema(tokenInfo).omit({
  id: true,
  updatedAt: true,
});

export const insertCommunityStatsSchema = createInsertSchema(communityStats).omit({
  id: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertTokenInfo = z.infer<typeof insertTokenInfoSchema>;
export type TokenInfo = typeof tokenInfo.$inferSelect;
export type InsertCommunityStats = z.infer<typeof insertCommunityStatsSchema>;
export type CommunityStats = typeof communityStats.$inferSelect;
