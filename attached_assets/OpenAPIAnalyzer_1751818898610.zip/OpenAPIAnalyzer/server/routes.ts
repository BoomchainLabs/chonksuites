import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize database with token data if not exists
  const initializeData = async () => {
    try {
      const existingToken = await storage.getTokenInfo();
      if (!existingToken) {
        await storage.updateTokenInfo({
          symbol: "CHONK9K",
          name: "$CHONK9K",
          currentPrice: "0.000137",
          marketCap: "1200000",
          volume24h: "450000",
          priceChange24h: "24.7",
          holders: 2847,
          totalSupply: "1000000000",
          contractAddresses: {
            pumpFun: "DnUsQnwNot38V9JbisNC18VHZkae1eKK5N2Dgy55pump",
            raydium: "51ey1T4UCFwb8poVBwyiLwwi1KdNTrZ8rSg7kBRmqray"
          }
        });
      }

      const existingStats = await storage.getCommunityStats();
      if (existingStats.length === 0) {
        await storage.updateCommunityStats([
          { platform: "telegram", memberCount: 5420, url: "https://t.me/chonk9k" },
          { platform: "twitter", memberCount: 8234, url: "https://twitter.com/chonk9k" },
          { platform: "discord", memberCount: 3156, url: "https://discord.gg/chonk9k" },
          { platform: "reddit", memberCount: 1987, url: "https://reddit.com/r/chonk9k" }
        ]);
      }
    } catch (error) {
      console.error("Error initializing data:", error);
    }
  };

  await initializeData();

  // Get token information
  app.get("/api/token/info", async (req, res) => {
    try {
      const tokenData = await storage.getTokenInfo();
      if (!tokenData) {
        return res.status(404).json({ error: "Token information not found" });
      }

      // Simulate slight price fluctuation for live feel
      const basePrice = parseFloat(tokenData.currentPrice);
      const variation = (Math.random() - 0.5) * 0.000001;
      const newPrice = Math.max(0, basePrice + variation);
      
      const responseData = {
        ...tokenData,
        currentPrice: newPrice.toFixed(6),
        updatedAt: new Date().toISOString()
      };

      res.json(responseData);
    } catch (error) {
      console.error("Error fetching token info:", error);
      res.status(500).json({ error: "Failed to fetch token information" });
    }
  });

  // Get community statistics
  app.get("/api/community/stats", async (req, res) => {
    try {
      const stats = await storage.getCommunityStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching community stats:", error);
      res.status(500).json({ error: "Failed to fetch community statistics" });
    }
  });

  // Get tokenomics data
  app.get("/api/tokenomics", async (req, res) => {
    try {
      const tokenomics = [
        {
          id: 1,
          name: "Liquidity Pool",
          percentage: 50,
          amount: "500M",
          description: "Locked for 2 years, ensuring stability and trust",
          status: "Locked",
          color: "cyan"
        },
        {
          id: 2,
          name: "Community",
          percentage: 30,
          amount: "300M",
          description: "Airdrops, rewards, and community events",
          status: "6 months vesting",
          color: "pink"
        },
        {
          id: 3,
          name: "Development",
          percentage: 20,
          amount: "200M",
          description: "Future features, partnerships, and growth",
          status: "12 months vesting",
          color: "purple"
        }
      ];

      res.json(tokenomics);
    } catch (error) {
      console.error("Error fetching tokenomics:", error);
      res.status(500).json({ error: "Failed to fetch tokenomics data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
