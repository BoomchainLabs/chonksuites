import { users, tokenInfo, communityStats, type User, type InsertUser, type TokenInfo, type InsertTokenInfo, type CommunityStats, type InsertCommunityStats } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getTokenInfo(): Promise<TokenInfo | undefined>;
  updateTokenInfo(tokenData: InsertTokenInfo): Promise<TokenInfo>;
  getCommunityStats(): Promise<CommunityStats[]>;
  updateCommunityStats(stats: InsertCommunityStats[]): Promise<CommunityStats[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getTokenInfo(): Promise<TokenInfo | undefined> {
    const [token] = await db.select().from(tokenInfo).limit(1);
    return token || undefined;
  }

  async updateTokenInfo(tokenData: InsertTokenInfo): Promise<TokenInfo> {
    const existing = await this.getTokenInfo();
    
    if (existing) {
      const [updated] = await db
        .update(tokenInfo)
        .set({ ...tokenData, updatedAt: new Date() })
        .where(eq(tokenInfo.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(tokenInfo)
        .values(tokenData)
        .returning();
      return created;
    }
  }

  async getCommunityStats(): Promise<CommunityStats[]> {
    return await db.select().from(communityStats);
  }

  async updateCommunityStats(stats: InsertCommunityStats[]): Promise<CommunityStats[]> {
    await db.delete(communityStats);
    
    if (stats.length > 0) {
      return await db
        .insert(communityStats)
        .values(stats)
        .returning();
    }
    
    return [];
  }
}

export const storage = new DatabaseStorage();
