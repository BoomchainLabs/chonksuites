import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";

export default function CommunitySection() {
  const { data: communityStats } = useQuery({
    queryKey: ["/api/community/stats"],
  });

  const { data: tokenData } = useQuery({
    queryKey: ["/api/token/info"],
    refetchInterval: 5000,
  });

  const socialLinks = [
    {
      name: "Telegram",
      icon: "fab fa-telegram-plane",
      color: "text-primary",
      hoverColor: "hover:text-accent",
      bgHover: "hover:bg-primary/10"
    },
    {
      name: "Twitter",
      icon: "fab fa-twitter",
      color: "text-accent",
      hoverColor: "hover:text-purple-400",
      bgHover: "hover:bg-accent/10"
    },
    {
      name: "Discord",
      icon: "fab fa-discord",
      color: "text-purple-400",
      hoverColor: "hover:text-green-400",
      bgHover: "hover:bg-purple-400/10"
    },
    {
      name: "Reddit",
      icon: "fab fa-reddit",
      color: "text-green-400",
      hoverColor: "hover:text-primary",
      bgHover: "hover:bg-green-400/10"
    }
  ];

  const stats = [
    {
      label: "CHONK HOLDERS",
      value: tokenData?.holders ? tokenData.holders.toLocaleString() : "2,847",
      color: "text-accent"
    },
    {
      label: "24H VOLUME",
      value: tokenData?.volume24h ? `$${(parseFloat(tokenData.volume24h) / 1000).toFixed(0)}K` : "$450K",
      color: "text-primary"
    },
    {
      label: "MARKET CAP",
      value: tokenData?.marketCap ? `$${(parseFloat(tokenData.marketCap) / 1000000).toFixed(1)}M` : "$1.2M",
      color: "text-green-400"
    }
  ];

  return (
    <section id="community" className="relative z-30 py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-cyber font-bold neon-text-purple mb-6">
            JOIN THE CHONK
          </h2>
          <p className="text-xl text-primary/70 max-w-3xl mx-auto">
            Connect with fellow chonkers and stay updated on the latest developments
          </p>
        </motion.div>

        {/* Social Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {socialLinks.map((link, index) => {
            const memberCount = communityStats?.find(stat => stat.platform.toLowerCase() === link.name.toLowerCase())?.memberCount;
            
            return (
              <motion.a
                key={link.name}
                href="#"
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="group"
              >
                <div className={`hologram-panel rounded-xl p-8 text-center ${link.bgHover} transition-all duration-300 hover:scale-105`}>
                  <div className={`text-4xl mb-4 ${link.color} ${link.hoverColor} transition-colors`}>
                    <i className={link.icon}></i>
                  </div>
                  <h3 className={`text-xl font-cyber font-bold mb-2 ${link.color}`}>
                    {link.name}
                  </h3>
                  {memberCount && (
                    <p className="text-white/70 text-sm">
                      {memberCount.toLocaleString()} members
                    </p>
                  )}
                </div>
              </motion.a>
            );
          })}
        </div>

        {/* Community Stats */}
        <div className="grid md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="glass-morphism rounded-2xl p-8 text-center border border-primary/20"
            >
              <div className={`text-4xl font-cyber font-bold mb-2 ${stat.color}`}>
                {stat.value}
              </div>
              <div className="text-gray-300">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
