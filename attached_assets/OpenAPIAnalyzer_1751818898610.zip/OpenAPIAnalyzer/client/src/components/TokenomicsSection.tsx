import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";

export default function TokenomicsSection() {
  const { data: tokenomicsData } = useQuery({
    queryKey: ["/api/tokenomics"],
  });

  const { data: tokenData } = useQuery({
    queryKey: ["/api/token/info"],
    refetchInterval: 5000,
  });

  const stats = [
    {
      label: "Price",
      value: tokenData?.currentPrice ? `$${tokenData.currentPrice}` : "$0.000137",
      change: tokenData?.priceChange24h ? `+${tokenData.priceChange24h}%` : "+24.7%",
      color: "text-primary"
    },
    {
      label: "Market Cap",
      value: tokenData?.marketCap ? `$${(parseFloat(tokenData.marketCap) / 1000000).toFixed(1)}M` : "$1.2M",
      change: "+15.3%",
      color: "text-primary"
    },
    {
      label: "Holders",
      value: tokenData?.holders ? tokenData.holders.toLocaleString() : "2,847",
      change: "+8.9%",
      color: "text-primary"
    },
    {
      label: "24h Volume",
      value: tokenData?.volume24h ? `$${(parseFloat(tokenData.volume24h) / 1000).toFixed(0)}K` : "$450K",
      change: "+42.1%",
      color: "text-primary"
    }
  ];

  return (
    <section id="tokenomics" className="relative z-30 py-20 px-6">
      <div className="container mx-auto max-w-6xl">
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="hologram-panel rounded-xl p-6 text-center hover:scale-105 transition-all duration-300 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 opacity-50"></div>
              <div className="relative z-10">
                <div className={`text-3xl font-cyber font-bold neon-text mb-2`}>
                  {stat.value}
                </div>
                <div className="text-primary/70">{stat.label}</div>
                <div className="text-sm text-green-400 mt-1">{stat.change}</div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-cyber font-bold neon-text mb-6">
            TOKENOMICS
          </h2>
          <p className="text-xl text-primary/70 max-w-3xl mx-auto">
            Fair distribution designed for maximum community growth and sustainability
          </p>
        </motion.div>

        {/* Tokenomics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tokenomicsData?.map((item: any, index: number) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="hologram-panel rounded-xl p-8 hover:bg-primary/10 transition-all duration-300 group"
            >
              <div className="text-center mb-6">
                <div className={`w-16 h-16 mx-auto mb-4 bg-gradient-to-r ${
                  item.color === 'cyan' ? 'from-primary to-accent' :
                  item.color === 'pink' ? 'from-accent to-purple-500' :
                  'from-purple-500 to-green-400'
                } rounded-full flex items-center justify-center text-2xl font-bold text-background`}>
                  {item.percentage}%
                </div>
                <h3 className={`text-xl font-cyber font-bold mb-2 ${
                  item.color === 'cyan' ? 'text-primary' :
                  item.color === 'pink' ? 'text-accent' :
                  'text-purple-400'
                }`}>
                  {item.name}
                </h3>
                <p className={`text-sm ${
                  item.color === 'cyan' ? 'text-primary/70' :
                  item.color === 'pink' ? 'text-accent/70' :
                  'text-purple-400/70'
                }`}>
                  {item.description}
                </p>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-white/70">Amount:</span>
                  <span className={`font-mono ${
                    item.color === 'cyan' ? 'text-primary' :
                    item.color === 'pink' ? 'text-accent' :
                    'text-purple-400'
                  }`}>
                    {item.amount} $CHONK9K
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-white/70">Status:</span>
                  <span className="text-green-400 font-semibold">{item.status}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
