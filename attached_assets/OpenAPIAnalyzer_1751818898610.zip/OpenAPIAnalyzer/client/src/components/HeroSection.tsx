import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function HeroSection() {
  const [currentPrice, setCurrentPrice] = useState("0.000137");

  const { data: tokenData } = useQuery({
    queryKey: ["/api/token/info"],
    refetchInterval: 5000, // Update every 5 seconds
  });

  useEffect(() => {
    if (tokenData?.currentPrice) {
      setCurrentPrice(tokenData.currentPrice);
    }
  }, [tokenData]);

  return (
    <section className="relative z-30 min-h-screen flex items-center justify-center px-6 py-20">
      {/* Cyberpunk cityscape background */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 opacity-30 bg-cover bg-center"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80')"
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/50"></div>
      </div>

      <div className="relative z-10 text-center max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-12"
        >
          <h1 className="text-6xl md:text-8xl font-cyber font-black mb-6">
            <span className="bg-gradient-to-r from-primary via-accent to-purple-500 bg-clip-text text-transparent animate-neon-pulse">
              CHONK HARD,
            </span>
          </h1>
          <h2 className="text-4xl md:text-6xl font-cyber font-bold neon-text mb-8">
            PUMP HARDER!
          </h2>
          <p className="text-xl md:text-2xl text-primary/80 max-w-3xl mx-auto mb-12 font-light">
            The ultimate cyberpunk cat token taking over the blockchain with neon-powered community energy
          </p>
        </motion.div>

        {/* Cyberpunk Cat Mascot */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative mb-12 flex justify-center"
        >
          <div className="relative">
            <div className="w-64 h-64 md:w-80 md:h-80 rounded-full bg-gradient-to-r from-primary/30 to-accent/30 animate-float flex items-center justify-center">
              <div className="text-8xl md:text-9xl">🐱</div>
            </div>
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-primary/30 to-accent/30 animate-glow"></div>
            <div className="absolute -inset-4 rounded-full border-2 border-primary/50 animate-pulse"></div>
          </div>
        </motion.div>

        {/* Live Price Display */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="hologram-panel rounded-2xl p-8 mb-12 max-w-md mx-auto"
        >
          <div className="text-primary text-sm font-medium mb-2">LIVE PRICE</div>
          <div className="font-cyber text-4xl font-bold text-white mb-2">
            ${currentPrice}
          </div>
          <div className="flex items-center justify-center">
            <span className="text-green-400 text-sm">↗ +24.7%</span>
            <span className="text-gray-400 text-sm ml-2">24h</span>
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-6 justify-center items-center"
        >
          <Button className="group relative px-8 py-4 bg-gradient-to-r from-primary to-accent rounded-lg font-cyber font-bold text-lg hover:scale-105 transition-all duration-300 animate-glow text-background">
            <span className="relative z-10">BUY $CHONK9K</span>
            <div className="absolute inset-0 bg-gradient-to-r from-accent to-purple-500 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </Button>

          <Button className="px-8 py-4 hologram-panel rounded-lg font-cyber font-bold text-lg text-primary hover:bg-primary/20 transition-all duration-300 bg-transparent border border-primary">
            View Chart
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
