import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Copy, Check } from "lucide-react";

export default function HowToBuySection() {
  const [copiedPump, setCopiedPump] = useState(false);
  const [copiedRaydium, setCopiedRaydium] = useState(false);

  const pumpFunAddress = "DnUsQnwNot38V9JbisNC18VHZkae1eKK5N2Dgy55pump";
  const raydiumAddress = "51ey1T4UCFwb8poVBwyiLwwi1KdNTrZ8rSg7kBRmqray";

  const handleCopyPump = async () => {
    try {
      await navigator.clipboard.writeText(pumpFunAddress);
      setCopiedPump(true);
      setTimeout(() => setCopiedPump(false), 2000);
    } catch (error) {
      console.error("Failed to copy:", error);
    }
  };

  const handleCopyRaydium = async () => {
    try {
      await navigator.clipboard.writeText(raydiumAddress);
      setCopiedRaydium(true);
      setTimeout(() => setCopiedRaydium(false), 2000);
    } catch (error) {
      console.error("Failed to copy:", error);
    }
  };

  const steps = [
    {
      step: "1",
      title: "Set Up Wallet",
      description: "Download MetaMask or your preferred Web3 wallet and create an account",
      color: "from-primary to-accent",
      textColor: "text-primary"
    },
    {
      step: "2",
      title: "Get SOL",
      description: "Purchase Solana (SOL) from any exchange and transfer to your wallet",
      color: "from-accent to-purple-500",
      textColor: "text-accent"
    },
    {
      step: "3",
      title: "Connect to DEX",
      description: "Connect your wallet to Jupiter or Raydium decentralized exchange",
      color: "from-purple-500 to-green-400",
      textColor: "text-purple-400"
    },
    {
      step: "4",
      title: "Swap for $CHONK9K",
      description: "Use the contract address to swap your SOL for $CHONK9K tokens",
      color: "from-green-400 to-primary",
      textColor: "text-green-400"
    }
  ];

  return (
    <section id="how-to-buy" className="relative z-30 py-20 px-6 bg-gradient-to-b from-transparent via-muted/10 to-transparent">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-cyber font-bold neon-text-pink mb-6">
            HOW TO BUY
          </h2>
          <p className="text-xl text-primary/70 max-w-3xl mx-auto">
            Follow these simple steps to join the $CHONK9K revolution
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {steps.map((step, index) => (
            <motion.div
              key={step.step}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="hologram-panel rounded-xl p-8 hover:scale-105 transition-all duration-300 h-full">
                <div className="text-center mb-6">
                  <div className={`w-12 h-12 mx-auto mb-4 bg-gradient-to-r ${step.color} rounded-full flex items-center justify-center text-xl font-cyber font-bold text-background`}>
                    {step.step}
                  </div>
                  <h3 className={`text-xl font-cyber font-bold mb-4 ${step.textColor}`}>
                    {step.title}
                  </h3>
                </div>
                <div className="space-y-4">
                  <p className={`text-sm text-center ${step.textColor}/70`}>
                    {step.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Contract Addresses */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center space-y-6"
        >
          {/* Pump.fun Address */}
          <div className="hologram-panel rounded-xl p-6 max-w-2xl mx-auto">
            <h4 className="text-xl font-cyber font-bold text-primary mb-4">
              CONTRACT ADDRESS (PUMP.FUN)
            </h4>
            <div className="flex items-center justify-center space-x-4 bg-muted/50 rounded-lg p-4">
              <code className="font-mono text-primary text-sm break-all flex-1 text-center">
                {pumpFunAddress}
              </code>
              <Button
                onClick={handleCopyPump}
                variant="ghost"
                size="icon"
                className="text-accent hover:text-primary transition-colors flex-shrink-0"
              >
                {copiedPump ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>

          {/* Raydium Address */}
          <div className="hologram-panel rounded-xl p-6 max-w-2xl mx-auto">
            <h4 className="text-xl font-cyber font-bold text-accent mb-4">
              CONTRACT ADDRESS (RAYDIUM)
            </h4>
            <div className="flex items-center justify-center space-x-4 bg-muted/50 rounded-lg p-4">
              <code className="font-mono text-accent text-sm break-all flex-1 text-center">
                {raydiumAddress}
              </code>
              <Button
                onClick={handleCopyRaydium}
                variant="ghost"
                size="icon"
                className="text-purple-400 hover:text-accent transition-colors flex-shrink-0"
              >
                {copiedRaydium ? (
                  <Check className="h-4 w-4" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
