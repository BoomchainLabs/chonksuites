import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import TokenomicsSection from "@/components/TokenomicsSection";
import HowToBuySection from "@/components/HowToBuySection";
import CommunitySection from "@/components/CommunitySection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Background Effects */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute inset-0 cyber-grid opacity-20"></div>
        <div className="absolute w-2 h-2 bg-primary rounded-full animate-float" style={{ top: "20%", left: "10%", animationDelay: "0s" }}></div>
        <div className="absolute w-1 h-1 bg-accent rounded-full animate-float" style={{ top: "60%", left: "80%", animationDelay: "1s" }}></div>
        <div className="absolute w-3 h-3 bg-purple-500 rounded-full animate-float" style={{ top: "80%", left: "20%", animationDelay: "2s" }}></div>
        <div className="absolute w-1 h-1 bg-green-400 rounded-full animate-float" style={{ top: "30%", left: "70%", animationDelay: "1.5s" }}></div>
      </div>

      <Navigation />
      <HeroSection />
      <TokenomicsSection />
      <HowToBuySection />
      <CommunitySection />
      <Footer />
    </div>
  );
}
