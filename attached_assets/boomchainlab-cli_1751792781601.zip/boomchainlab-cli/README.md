# Boomchainlab CLI

> Interactive command-line interface for modular smart contract deployment, NFT utility, and decentralized infra control.

## Features

- Modular architecture (add plugins per protocol or token)
- Interactive sessions using `is-interactive`
- Built-in scaffolders for Solidity, Rust, and Wasm contracts
- $CHONK9K and BoomPass ecosystem support
- Deployment workflows for Solana, Polygon, Base

## Installation

```bash
npm install -g @boomchainlab/cli
```

## Usage

```bash
boomchainlab --help
```

## Dependencies

- [`is-interactive`](https://www.npmjs.com/package/is-interactive)

## Security

[![Socket Security](https://socket.dev/api/badge/npm/package/is-interactive/1.0.0)](https://socket.dev/npm/package/is-interactive/overview/1.0.0)

## Roadmap

- [ ] Plugin support (e.g., `boomchainlab plugin add chonk`)
- [ ] Wallet signer integration (Phantom, WalletConnect)
- [ ] IPFS + Graph deployment flow
- [ ] Token/contract monitoring dashboard sync

## License

MIT © Boomchainlab
